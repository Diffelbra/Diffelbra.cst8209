// Import the Pokémon data
import pokedex from '.pokedex.js';
export default pokedex;
const pokedex = require('pokedex.js');

// Retrieve the unique types
let types = [];
pokedex.forEach(pokemon => {
  pokemon.type.forEach(type => {
    if (!types.includes(type)) {
      types.push(type);
    }
  });
});

// Create type-specific Pokédexes and calculate total HP and total Attack
let pokedexByType = {};
types.forEach(type => {
  let pokemons = pokedex.filter(pokemon => pokemon.type.includes(type));
  pokemons.sort((a, b) => a.name.localeCompare(b.name));
  let totalHP = pokemons.reduce((sum, pokemon) => sum + pokemon.base.HP, 0);
  let totalAttack = pokemons.reduce((sum, pokemon) => sum + pokemon.base.Attack, 0);
  pokedexByType[type] = { pokemons, totalHP, totalAttack };
});

// Display the Pokédex
for (let type of types.sort()) {
  console.log(`${type}:`);
  console.log(`  Total HP: ${pokedexByType[type].totalHP}`);
  console.log(`  Total Attack: ${pokedexByType[type].totalAttack}`);
  pokedexByType[type].pokemons.forEach(pokemon => {
    console.log(`  ${pokemon.name}`);
  });
}

// Divide by type
pokedex.forEach(pokemon => {
  pokemon.type.forEach(type => {
    if (!pokedexByType[type].pokemons) {
      pokedexByType[type].pokemons = [];
    }
    pokedexByType[type].pokemons.push(pokemon);
  });
});

// Sort each list
for (let type in pokedexByType) {
  pokedexByType[type].sort((a, b) => a.name.localeCompare(b.name));
}

// Create navigation bar
let navbar = document.createElement('div');
Object.keys(pokedexByType).sort().forEach(type => {
  let link = document.createElement('a');
  link.href = `#${type}`;
  link.textContent = type;
  navbar.appendChild(link);
});
document.body.appendChild(navbar);

// Create sections
for (let type of Object.keys(pokedexByType).sort()) {
  let section = document.createElement('section');
  section.id = type;

  let heading = document.createElement('h2');
  heading.textContent = type;
  section.appendChild(heading);

  let count = document.createElement('p');
  count.textContent = `Number of Pokémon: ${pokedexByType[type].length}`;
  section.appendChild(count);

  let totalHP = pokedexByType[type].reduce((sum, pokemon) => sum + pokemon.base.HP, 0);
  let totalAttack = pokedexByType[type].reduce((sum, pokemon) => sum + pokemon.base.Attack, 0);

  let hp = document.createElement('p');
  hp.textContent = `Total HP: ${totalHP}`;
  section.appendChild(hp);

  let attack = document.createElement('p');
  attack.textContent = `Total Attack: ${totalAttack}`;
  section.appendChild(attack);

  let list = document.createElement('ul');
  pokedexByType[type].forEach(pokemon => {
    let item = document.createElement('li');

    let img = document.createElement('img');
    img.src = pokemon.sprite;
    item.appendChild(img);

    let name = document.createElement('span');
    name.textContent = pokemon.name;
    item.appendChild(name);

    let stats = document.createElement('span');
    stats.textContent = JSON.stringify(pokemon.base);
    item.appendChild(stats);

    item.addEventListener('click', () => {
      window.open(pokemon.url, '_blank');
    });

    list.appendChild(item);
  });
  section.appendChild(list);

  document.body.appendChild(section);
}