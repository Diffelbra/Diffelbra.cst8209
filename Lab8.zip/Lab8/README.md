# Mad Libs

## Objective
Practice listening for and responding to events using JavaScript. 

