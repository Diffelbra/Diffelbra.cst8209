function getUniqueBeanTypes(counters) {
  const beanTypes = [];
  for (let i = 0; i < counters.length; i++) {
    const beanType = counters[i].bean;
    if (!beanTypes.includes(beanType)) {
      beanTypes.push(beanType);
    }
  }
  return beanTypes;
}

function sortCountersByName(counters) {
  return counters.slice().sort((a, b) => a.name.localeCompare(b.name));
}

function filterCountersByBeanType(counters, beanType) {
  return counters.filter((counter) => counter.bean === beanType);
}

function getTotalBeanCount(counters) {
  return counters.reduce((total, counter) => total + counter.count, 0);
}

function createBeanTypeList(counters) {
  const uniqueBeanTypes = getUniqueBeanTypes(counters);
  const container = document.querySelector(".beanTypes");
  counters = sortCountersByName(counters);

  uniqueBeanTypes.forEach((beanType) => {
    const filteredCounters = filterCountersByBeanType(counters, beanType);
    const totalBeanCount = getTotalBeanCount(filteredCounters);

    const beanList = document.createElement("ol");

    const beanTypeHeader = document.createElement("h2");
    beanTypeHeader.textContent = `${beanType} (${totalBeanCount})`;

    beanList.appendChild(beanTypeHeader);

    filteredCounters.forEach((counter) => {
      const listItem = document.createElement("li");
      listItem.textContent = `${counter.name} (${counter.count})`;

      beanList.appendChild(listItem);
    });

    container.appendChild(beanList);
  });
}

createBeanTypeList(counters);
