const $title = document.createElement('h1');
$title.innerHTML = 'Emoji Album';

const $body = document.body;

$body.insertBefore($title, $body.firstChild);

// document.body.appendChild($title);

const $emojiAlbum = document.querySelector('.emoji-album');

for (const faces in emoji) {

    const $insertEmoji = document.createElement('div')
    $insertEmoji.className = 'faces'
    $insertEmoji.innerHTML = `<span>${emoji[faces].char}</span><p>${emoji[faces].name}</p>`;
    $emojiAlbum.append($insertEmoji);
}

