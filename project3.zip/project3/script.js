const form = document.getElementById('apod-form');
const title = document.getElementById('apod-title');
const img = document.getElementById('apod-img');
const explanation = document.getElementById('apod-explanation');
const saveBtn = document.getElementById('save-btn');
const favouritesDiv = document.getElementById('favourites');
const API_KEY = 'LS8aWUHWStv3shNtNA5feiZVPzuycxMrKgaGqCnz';// ... existing code ...

// Save the current APOD as a favourite
saveBtn.addEventListener('click', function() {
    const favourites = JSON.parse(localStorage.getItem('favourites')) || [];
    const apod = JSON.parse(this.dataset.apod);
    favourites.push(apod);
    localStorage.setItem('favourites', JSON.stringify(favourites));
    displayFavourite(apod);
});

// Display a favourited APOD
function displayFavourite(apod) {
    const div = document.createElement('div');
    div.innerHTML = `
        <h2>${apod.title}</h2>
        <img src="${apod.url}" onclick="window.open('${apod.hdurl}', '_blank')">
        <p>${apod.explanation}</p>
        <button class="remove-btn">Remove</button>
    `;
    div.querySelector('.remove-btn').addEventListener('click', function() {
        div.remove();
        const favourites = JSON.parse(localStorage.getItem('favourites'));
        const index = favourites.findIndex(favourite => favourite.date === apod.date);
        favourites.splice(index, 1);
        localStorage.setItem('favourites', JSON.stringify(favourites));
    });
    favouritesDiv.appendChild(div);
}

// Display all favourited APODs on page load
const favourites = JSON.parse(localStorage.getItem('favourites')) || [];
favourites.forEach(displayFavourite);

// Set the maximum allowed date to today's date
document.getElementById('apod-date').max = new Date().toISOString().split('T')[0];

form.addEventListener('submit', function(e) {
    e.preventDefault();
    const date = document.getElementById('apod-date').value;
    const storedApod = localStorage.getItem(date);
    if (storedApod) {
        const data = JSON.parse(storedApod);
        displayApod(data);
    } else {
        fetch(`https://api.nasa.gov/planetary/apod?api_key=${API_KEY}&date=${date}`)
            .then(response => response.json())
            .then(data => {
                localStorage.setItem(date, JSON.stringify(data));
                displayApod(data);
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }
});

function displayApod(data) {
    title.textContent = data.title;
    img.src = data.url;
    img.onclick = () => window.open(data.hdurl, '_blank');
        window.open(data.hdurl, '_blank');
    explanation.textContent = data.explanation;
    saveBtn.dataset.apod = JSON.stringify(data);
}



// Display modal with image
function displayModal(imageUrl) {
    const modal = document.createElement('div');
    modal.innerHTML = `
        <div class="modal-content">
            <span class="close">&times;</span>
            <img src="${imageUrl}">
        </div>
    `;
    modal.querySelector('.close').addEventListener('click', function() {
        modal.remove();
    });
    document.body.appendChild(modal);x``
}