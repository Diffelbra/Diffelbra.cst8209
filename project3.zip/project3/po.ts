const form = document.getElementById('apod-form');
const title = document.getElementById('apod-title');
const img = document.getElementById('apod-img');
const explanation = document.getElementById('apod-explanation');
const saveBtn = document.getElementById('save-btn');
const favouritesDiv = document.getElementById('favourites');
const API_KEY = 'YOUR_NASA_API_KEY';

form.addEventListener('submit', function(e) {
    e.preventDefault();
    const date = document.getElementById('apod-date').value;
    const storedApod = localStorage.getItem(date);
    if (storedApod) {
        const data = JSON.parse(storedApod);
        displayApod(data);
    } else {
        fetch(`https://api.nasa.gov/planetary/apod?api_key=${API_KEY}&date=${date}`)
            .then(response => response.json())
            .then(data => {
                localStorage.setItem(date, JSON.stringify(data));
                displayApod(data);
            });
    }
});

function displayApod(data) {
    title.textContent = data.title;
    img.src = data.url;
    img.onclick = () => window.open(data.hdurl, '_blank');
    explanation.textContent = data.explanation;
    saveBtn.dataset.apod = JSON.stringify(data);
}

saveBtn.addEventListener('click', function() {
    const favourites = JSON.parse(localStorage.getItem('favourites')) || [];
    const apod = JSON.parse(this.dataset.apod);
    favourites.push(apod);
    localStorage.setItem('favourites', JSON.stringify(favourites));
    displayFavourite(apod);
});

// ... rest of the code remains the same ...