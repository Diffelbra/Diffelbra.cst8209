document.addEventListener("DOMContentLoaded", function () {
  const movieListContainer = document.getElementById("movieListContainer");
  const searchBox = document.getElementById("searchBox");

  function displayMovies(movies) {
    movieListContainer.innerHTML = "";

    movies.forEach((movie) => {
      const movieItem = document.createElement("div");
      movieItem.classList.add("movie-item");

      const titleYear = document.createElement("h2");
      titleYear.textContent = `${movie.title} (${movie.year})`;
      movieItem.appendChild(titleYear);

      const description = document.createElement("p");
      description.textContent = movie.description;
      description.classList.add("hidden");
      movieItem.appendChild(description);

      movieItem.addEventListener("click", function () {
        description.classList.toggle("hidden");
      });

      movieListContainer.appendChild(movieItem);
    });
  }

  displayMovies(movies);

  searchBox.addEventListener("input", function () {
    const searchTerm = searchBox.value.toLowerCase();
    const filteredMovies = movies.filter((movie) =>
      movie.title.toLowerCase().includes(searchTerm)
    );

    displayMovies(filteredMovies);
  });
});
